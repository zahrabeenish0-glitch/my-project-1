# UI/UX Design — Student Planner App

**Status:** Proposed design direction; no visual reference or brand identity supplied  
**Related documents:** [PRD.md](PRD.md), [appFlow.md](appFlow.md), [Rules.md](Rules.md)

## 1. Design goal

Make a calm, clear planner interface that helps university students quickly understand their tasks and deadlines. The interface should prioritize clarity over decoration.

## 2. Proposed visual direction

**Recommendation, not approved:** A clean, modern student dashboard with a light neutral background, one restrained accent color, simple cards, and readable typography. Avoid excessive gradients, animations, or crowded dashboards.

No existing brand colors, logo, typeface, or reference screenshot has been supplied.

## 3. Proposed design tokens

These are starter suggestions to be reviewed, not an established brand system.

| Token | Proposed value | Use |
|---|---|---|
| Page background | `#F7F8FA` | Main page background |
| Surface | `#FFFFFF` | Cards and form surfaces |
| Primary text | `#202938` | Main readable text |
| Secondary text | `#667085` | Supporting labels |
| Accent | `#5267D8` | Main action and selected controls |
| Success | `#23845B` | Completed-state cue, paired with text/icon |
| Warning | `#A76512` | Due-soon/overdue cue, paired with text/icon |
| Border | `#E2E6EC` | Dividers and input borders |
| Radius | 8–12 px | Cards and inputs |
| Spacing scale | 4, 8, 12, 16, 24, 32 px | Consistent spacing |

Check actual color contrast before implementation; the suggested palette is not a completed accessibility audit.

## 4. Typography and layout

- Use a readable system sans-serif font unless a specific font is approved.
- Use clear heading hierarchy and avoid tiny text.
- Keep the main task list visually prominent.
- Use a consistent spacing scale.
- Use a centered content area on wide screens and comfortable side padding on narrow screens.
- Avoid horizontal scrolling on mobile.

Exact font sizes and breakpoints should be set after the platform is confirmed.

## 5. Proposed screen layout

### Planner home
- Page title: “Student Planner” or another approved product name.
- Primary action: “Add task”.
- Optional summary cards for total, pending, completed, and overdue tasks.
- Task list with title, due date, status, and clear action controls.
- Optional filters: All, Pending, Completed.

Summary cards and filters are proposals, not confirmed requirements.

### Add-task form
- Clearly labeled title input.
- Due-date input.
- Additional fields only if approved.
- Visible validation feedback near the relevant field.
- Save and Cancel actions if a separate form/dialog is used.

Whether the form is a page, dialog, or inline section is unresolved.

## 6. Component guidance

| Component | Guidance |
|---|---|
| Primary button | Clear action label; visible focus; disabled state when genuinely unavailable |
| Text input | Persistent label; helpful validation message |
| Date input | Display selected date clearly and consistently |
| Task item/card | Keep title and deadline easy to scan |
| Completion control | Use an accessible label such as “Mark as completed”; do not rely only on color |
| Delete control | Clearly labeled; confirmation is recommended if deletion cannot be undone |
| Empty state | Explain that no tasks are available and offer an add-task action |
| Feedback message | State success or failure in plain language |

## 7. Task status appearance

- Pending: neutral status label.
- Completed: clear “Completed” text and/or check icon.
- Overdue: clear “Overdue” text and/or warning icon if the overdue rule is approved.
- Status must not be communicated by color alone.

## 8. Responsive behavior

If a website is selected:
- **Narrow screens:** Stack summary items, use a single-column task list, and keep primary actions reachable.
- **Medium screens:** Allow summary items to sit side-by-side when there is enough room.
- **Wide screens:** Use a centered main content area and a comfortable reading width.
- Avoid relying on hover; touch users need the same actions.

Exact breakpoints are implementation decisions pending platform and framework choice.

## 9. Accessibility requirements

- Use semantic page landmarks and a logical heading structure.
- Associate labels with form controls.
- Ensure keyboard users can reach and operate all actions.
- Show visible focus.
- Use readable text and verify color contrast.
- Provide accessible names for icon-only controls, or use visible text.
- Announce important success/error feedback accessibly where supported.
- Do not use color as the sole status signal.

## 10. Motion and assets

No animation, external image, icon library, or branded asset is required by the current scope. Prefer simple icons or text labels. Any icon library should be chosen only if needed and approved.

## 11. Open design questions

- Preferred style: minimal, colorful, pastel, dark, or another direction?
- Should the first version be optimized for laptop, phone, or both?
- Are dashboard counts and filters desired?
- Should the task form be inline, a dialog, or a separate screen?
