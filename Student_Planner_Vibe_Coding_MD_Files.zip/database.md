# Data Model — Student Planner App

**Status:** Draft; persistence option not approved  
**Related documents:** [PRD.md](PRD.md), [TRD.md](TRD.md), [Architecture.md](Architecture.md)

## 1. Storage decision

No database has been confirmed.

### Proposed Option A: browser local storage
For a single-device website, store a serialized collection of task records in browser storage. This is not a relational database and does not need SQL tables or an ER diagram.

### Alternative Option B: cloud database
If account-based, cross-device access is required, select a database and authentication/authorization approach before finalizing the schema. The current context does not support choosing a provider.

## 2. Proposed task record

The following is a **candidate model**, not an approved schema. Confirm the fields before implementation.

| Field | Candidate type | Purpose | Status |
|---|---|---|---|
| `id` | String identifier | Distinguish tasks, including tasks with the same title | Recommended |
| `title` | String | Short task/assignment name | Strongly inferred; confirm required |
| `dueDate` | Date-only string (`YYYY-MM-DD`) or null | Assignment deadline | Deadline capability confirmed; optionality unresolved |
| `isCompleted` | Boolean | Track whether work is completed | Required behavior |
| `createdAt` | Timestamp/string | Optional creation time for sorting or diagnostics | Optional proposal |
| `course` | String or null | Course/subject name | Unresolved; do not implement without approval |
| `notes` | String or null | Additional details | Unresolved; do not implement without approval |
| `priority` | Enumerated value or null | Optional priority | Unresolved; do not implement without approval |

Avoid adding fields merely because they are common in planner apps.

## 3. Candidate local-storage shape

If local storage is approved, the app could store an array of task records under one versioned key, such as a project-specific key. The exact key and schema version should be selected during implementation.

Example data shape (illustrative only):

```json
[
  {
    "id": "example-task-id",
    "title": "Prepare programming assignment",
    "dueDate": "2026-10-25",
    "isCompleted": false
  }
]
```

This is an example, not real user data or a finalized contract.

## 4. Relationships

For the proposed single-user, browser-only MVP, no separate user or course table is necessary unless additional requirements justify it.

If cloud accounts are later introduced, a task will need an ownership relationship or equivalent access-control rule so that one student cannot read or modify another student's tasks.

## 5. Validation and constraints

Proposed constraints, subject to confirmation:
- `id` must be unique.
- `title` must not be blank if title is confirmed as required.
- `dueDate`, if present, must be a valid date-only value.
- `isCompleted` must be boolean.
- Unknown or malformed stored records should not crash the app.

No rule currently requires unique titles. Two different tasks may have the same title unless a different rule is agreed.

## 6. Create, update, and delete behavior

- **Create:** Add a new record with a unique ID and pending status.
- **Complete:** Update the completion field.
- **Delete:** Remove the record from the active collection.
- **Reopen:** Unresolved; do not assume this behavior is required.
- **Retention:** No archive/recycle-bin requirement has been stated.
- **Deletion:** The user requested delete; permanent removal from the selected storage collection is the proposed default, pending confirmation of whether undo/confirmation is desired.

## 7. Date handling

Use a date-only representation for assignment deadlines if exact times are not required. Avoid converting a date-only value through UTC in a way that could show the previous or next day. Define the overdue comparison against the local calendar date.

## 8. Migration and backup

- Local storage has no automatic cross-device backup.
- If the schema changes, validate existing records and handle older or malformed values safely.
- Cloud migration, export/import, backups, and retention are out of scope until a cloud or backup requirement is approved.

## 9. Open questions

1. Is local browser storage acceptable?
2. What exact task fields are required?
3. Is a due date optional?
4. Should tasks be permanently deleted or recoverable?
5. Is export/backup needed?
6. If accounts are required, what data service and access rules will be used?
