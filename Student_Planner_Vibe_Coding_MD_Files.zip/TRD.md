# TRD — Technical Requirements Document

**Status:** Draft; technology decisions are not yet approved  
**Related documents:** [PRD.md](PRD.md), [Architecture.md](Architecture.md), [database.md](database.md), [Rules.md](Rules.md)

## 1. Purpose

This document records technical needs and candidate implementation choices for the Student Planner App. It distinguishes requirements from recommendations.

## 2. Confirmed technical constraints

- The product must support task creation, deletion, deadline tracking, pending-task visibility, and completion status.
- The project is intended to be built as a Vibe Coding Club project.
- No programming language, framework, database, hosting service, or repository setup has been confirmed.

## 3. Proposed implementation options

### Option A — Responsive website with browser storage (recommended for a small beginner MVP)
- **UI:** HTML, CSS, and JavaScript, or a beginner-friendly frontend framework if required by the club.
- **Storage:** Browser `localStorage`.
- **Backend/API:** None for the initial version.
- **Hosting:** Static web hosting, if an online demo is required.
- **Benefits:** Small scope, low cost, no account setup, no server to maintain.
- **Trade-offs:** Data remains on the same browser/device; browser data can be cleared; no multi-device sync or shared accounts.

### Option B — Website with accounts and cloud database
- **UI:** To be chosen.
- **Backend/data service:** A managed service or custom backend and database.
- **Benefits:** Can support accounts and access across devices.
- **Trade-offs:** More setup, authorization and privacy work, configuration, and possible service limits or costs.
- **Status:** Not recommended for the first build unless cross-device access is required.

### Option C — Native Android app
- Requires a separate mobile-app technology decision and a suitable storage approach.
- **Status:** Unresolved; do not assume this option.

## 4. Recommended technical direction — approval required

For the simplest first release, use a responsive website with browser storage. This is a proposal, not a confirmed decision. Before implementation, confirm the platform, storage needs, and the coding environment expected by the club.

## 5. Functional technical requirements

| ID | Technical requirement |
|---|---|
| TR-001 | The UI must provide create, list, complete, and delete task operations consistent with FR-001 through FR-006. |
| TR-002 | Required form inputs must be validated before a task is saved. |
| TR-003 | The app must display clear feedback for invalid input and unexpected storage failures. |
| TR-004 | If browser storage is selected, task data must be serialized and parsed safely, with a reasonable fallback if saved data is invalid or unavailable. |
| TR-005 | If a cloud database is later selected, users must only access tasks they are authorized to access. |
| TR-006 | Dates must be stored and displayed consistently, avoiding accidental date shifts caused by timezone conversion. |
| TR-007 | The implementation must be testable without requiring production user data. |
| TR-008 | No secret keys, passwords, or credentials may be committed to the repository. |

## 6. Data and interface conventions

- Authoritative task fields and storage model are pending confirmation; see [database.md](database.md).
- The app currently has no confirmed external APIs or third-party integrations.
- If no backend is chosen, do not invent REST endpoints or claim that an API exists.
- Date-only assignment deadlines are the current working interpretation; exact deadline times are unresolved.

## 7. Security and privacy

### For browser-only storage
- Do not request sensitive personal information.
- Explain the limitation that tasks are stored locally on the device/browser.
- Handle malformed stored data without crashing.
- Do not treat local storage as secure storage for secrets.

### If accounts/cloud storage are added
- Authentication and authorization must be designed before implementation.
- Enforce access control in trusted backend/database rules, not only by hiding UI elements.
- Keep credentials in environment/configuration settings appropriate to the platform.
- Define account deletion and task-data deletion behavior.

## 8. Accessibility and compatibility

If the project is a website:
- Use semantic HTML and labeled form controls.
- Ensure keyboard navigation and visible focus.
- Do not use color as the only indicator of task status.
- Test at a narrow mobile width and a desktop width.
- Confirm supported browsers before release; no specific browser matrix has been agreed.

## 9. Testing requirements

- Unit-test date/status helpers and validation logic where practical.
- Test task create, complete, delete, and reload persistence.
- Test empty input, invalid dates, missing optional values, and malformed saved data.
- Test keyboard operation and responsive layout.
- If a backend is introduced, add integration tests for real data access boundaries.
- Keep unit tests distinct from integration and end-to-end tests.

## 10. Deployment and operations

- Hosting provider and deployment target are unresolved.
- A static website can be deployed to a static host if selected.
- No monitoring, analytics, logging service, backup service, or uptime target is currently required.
- Document any deployment steps and configuration after the hosting choice is approved.

## 11. Open technical decisions

1. Platform: website, Android, or both.
2. Storage: local browser storage or cloud database with accounts.
3. Frontend language/framework.
4. Required hosting/demo method.
5. Whether automated tests are expected by the club and which tools are available.
