# PRD — Student Planner App

**Status:** Draft for project discovery  
**Product name:** Student Planner App (working name)  
**Last updated:** 2026-10-18

## 1. Product overview

The Student Planner App is intended to help university students organize assignments and other study tasks, set deadlines, see unfinished work, and mark work as completed.

### Problem statement
University students may need a simple place to record tasks and deadlines and to understand what remains unfinished. The app should make it easier to review pending work rather than relying only on memory.

### Product goal
Provide a straightforward task-planning experience for university students.

## 2. Decision status

- **Confirmed:** The user wants a student planner for university students.
- **Confirmed:** Users should be able to add and delete tasks, set assignment deadlines, track pending tasks, and mark work as completed.
- **Inferred:** A task list and a simple dashboard would help users understand their workload.
- **Proposed, not approved:** Build a responsive website first and store tasks in the same browser using local storage. This is a beginner-friendly approach for a small demo.
- **Unresolved:** Website versus native mobile app; local browser storage versus user accounts and cross-device sync; exact task fields; preferred visual style; chosen technology stack.

## 3. Target users

### Primary user
A university student who wants to keep assignment and study tasks organized.

### User needs
- Add a task without a complicated setup.
- Know when an assignment is due.
- See which tasks are still pending.
- Mark a task complete when finished.
- Remove a task that is no longer needed.

Authentication and multiple user roles are **not confirmed requirements**.

## 4. Goals and non-goals

### Goals
- Make task creation, viewing, completion, and deletion clear.
- Make deadlines easy to see.
- Distinguish pending, completed, and overdue tasks where dates allow it.
- Keep the first version small enough to complete and demonstrate.

### Non-goals for the MVP
Unless later approved, the MVP will not include:
- User registration, login, or cloud synchronization.
- Notifications, email reminders, or calendar integrations.
- File uploads, assignment submissions, or collaboration.
- AI-generated study plans.
- Grade tracking, attendance, or a full learning-management system.

## 5. Functional requirements

Priority meanings: **Must** = core MVP; **Should** = recommended if time allows; **Later** = not part of the initial build unless approved.

| ID | Priority | Requirement | Acceptance criteria |
|---|---|---|---|
| FR-001 | Must | Create a task | A user can enter the required task details and save. The new task appears in the task list. Invalid or missing required values receive a clear message. |
| FR-002 | Must | View tasks | The app displays saved tasks and their relevant deadline and status information. |
| FR-003 | Must | Set an assignment deadline | A user can select a due date for a task. The chosen date is displayed consistently. Whether a deadline is optional remains unresolved. |
| FR-004 | Must | Mark a task completed | A user can change a pending task to completed, and the UI visibly reflects the new state. |
| FR-005 | Must | Delete a task | A user can delete a task. The task is removed from the visible list after confirmation or an equivalent safe interaction. Whether confirmation is required is unresolved. |
| FR-006 | Must | Track pending tasks | The app makes unfinished tasks identifiable. |
| FR-007 | Should | Summarize task counts | A simple summary may show total, pending, completed, and overdue counts. This is a recommendation and needs approval. |
| FR-008 | Should | Identify overdue tasks | If a task has a due date earlier than the current local date and is not completed, the app labels it overdue. Confirm the desired rule before implementation. |
| FR-009 | Should | Filter tasks by status | Users may switch between all, pending, and completed tasks. This is proposed, not confirmed. |

## 6. Non-functional requirements

| ID | Requirement | Acceptance criteria |
|---|---|---|
| NFR-001 | Ease of use | Main actions are labeled clearly and can be completed without technical knowledge. |
| NFR-002 | Responsive layout | If a website is selected, the core task workflow remains usable on narrow mobile screens and desktop screens. |
| NFR-003 | Data clarity | Dates and task status are displayed consistently; validation messages explain what needs fixing. |
| NFR-004 | Privacy | Do not collect personal data that the app does not need. If local browser storage is selected, explain that data is tied to that browser/device. |
| NFR-005 | Reliability | Saving, completing, and deleting tasks should not silently fail. Errors should be communicated clearly. |
| NFR-006 | Accessibility | Controls have meaningful labels, visible keyboard focus, readable contrast, and semantic structure. |
| NFR-007 | Maintainability | Keep the implementation simple and document important decisions. |

Specific performance, availability, and scale targets are not known and should not be invented for this small project.

## 7. User stories

- As a student, I want to add an assignment so I can remember that it needs to be done.
- As a student, I want to set a due date so I can plan around deadlines.
- As a student, I want to see pending tasks so I know what work remains.
- As a student, I want to mark a task complete so my list reflects my progress.
- As a student, I want to delete an unneeded task so my list stays useful.

## 8. MVP scope

### Included
- Create and display tasks.
- Store a task deadline, if the chosen data rules require it.
- Show pending/completed status.
- Mark tasks completed.
- Delete tasks.
- Validate required input.
- Provide basic empty and error states.

### Recommended, pending approval
- A compact dashboard with counts.
- All/Pending/Completed filters.
- Overdue labeling.
- Responsive website layout.

### Out of scope unless approved
Accounts, synchronization, reminders, integrations, uploads, collaboration, AI planning, grades, and attendance.

## 9. Risks and dependencies

- **Platform decision:** Native mobile versus website changes the technology and delivery approach.
- **Storage decision:** Browser-only storage is simple but does not sync across devices and may be lost if browser data is cleared.
- **Unspecified task fields:** Title, course/subject, notes, priority, and optional due date have not all been confirmed.
- **Deadline handling:** Date-only deadlines need a consistent local-date rule; exact times are not currently requested.
- **Scope risk:** Adding accounts, reminders, and cloud services may exceed the intended beginner project scope.

## 10. Success evaluation

Success metrics and numeric targets have not been supplied. For a demonstration, proposed checks are:
- A user can create a task and see it in the list.
- A user can mark a task complete and see its status update.
- A user can delete a task.
- A due date is saved and shown correctly.
- The app handles empty and invalid inputs without crashing.

## 11. Glossary

- **Task:** A piece of work the student wants to track.
- **Deadline / due date:** The date by which the task should be finished.
- **Pending:** Not marked as completed.
- **Completed:** Marked as finished.
- **Overdue:** Proposed label for a pending task whose due date has passed.

## 12. Open questions

1. Should this be a website, an Android app, or both?
2. Should tasks stay in one browser/device, or should students sign in and sync across devices?
3. Which fields should a task have: title only, or also course, description/notes, priority, and due date?
4. Should a task's due date be required or optional?
5. Is a dashboard and filtering needed for the first version?
6. What visual style does the user prefer?
7. Which coding tools/technology are expected by the Vibe Coding Club?
