# AI Development Rules — Student Planner App

These rules guide any AI coding assistant working on this project. They do not authorize unapproved features or settle unresolved product decisions.

## 1. Read the documentation first

1. Read `PRD.md`, `TRD.md`, `Architecture.md`, `appFlow.md`, `database.md`, `design.md`, and `phases.md` before making project changes.
2. Treat confirmed requirements as authoritative.
3. Treat items labeled **Proposed**, **Inferred**, **TODO**, or **Unresolved** as not approved.
4. Do not silently convert a proposal into a requirement.

## 2. Stay within scope

- Implement only approved features and the current implementation phase.
- The confirmed core behavior is task creation, deletion, deadline handling, pending-task tracking, and marking tasks complete.
- Do not add login, cloud sync, reminders, AI features, file uploads, grades, attendance, or integrations without approval.
- If a missing decision blocks implementation, ask one focused question. If it does not block work, record the assumption and stay within the documented scope.

## 3. Architecture and technology

- Follow the approved stack and architecture once they are selected.
- Do not invent a backend, API, database provider, framework, or folder structure.
- Keep the solution as simple as the requirements allow.
- Keep task operations, input validation, UI rendering, and persistence reasonably separated where the chosen stack supports it.
- Avoid unnecessary dependencies and avoid refactoring unrelated code.

## 4. Code quality

- Use clear, consistent names.
- Follow the conventions of the selected language and framework.
- Keep functions focused and avoid unnecessary duplication.
- Handle empty, invalid, and unexpected input.
- Avoid hidden side effects and unexplained magic values.
- Add comments for non-obvious decisions, not for every line.
- Do not introduce complexity that the project does not need.

## 5. Data and privacy

- Store only data required by approved features.
- Never hardcode secrets, passwords, private keys, or service credentials.
- If browser storage is approved, treat saved data as potentially malformed and handle parsing/storage errors.
- Do not store secrets in browser storage.
- If accounts or a backend are approved later, enforce authorization in a trusted backend/database layer, not only in the UI.
- Follow the approved delete and retention behavior.

## 6. Validation and errors

- Validate required task fields before saving.
- Validate any supplied deadline as a real date.
- Show useful feedback when validation fails.
- Do not show a success message until the relevant operation has actually succeeded.
- If storage or a service operation fails, keep the UI consistent with persisted data and explain the failure.
- Avoid exposing internal stack traces or sensitive implementation details to users.

## 7. UI and accessibility

- Follow the approved design tokens and component patterns.
- Use semantic markup and properly labeled inputs.
- Preserve keyboard access and visible focus.
- Do not use color alone to convey task status.
- Test the layout at narrow and wide viewport sizes if the app is responsive.
- Ensure controls have clear labels and understandable disabled/error states.

## 8. Testing and verification

- Add or update tests for each changed behavior where the selected stack supports testing.
- Test create, view, complete, delete, deadline display, and persistence behavior as applicable.
- Test invalid and empty input, empty lists, and storage/service failures.
- Run applicable unit tests, integration tests, and regression tests at the end of each implementation phase.
- Do not claim tests passed unless they were run and the results are known.
- If tests cannot be run, state why and what remains unverified.

## 9. Documentation and traceability

- Keep requirement IDs and names consistent.
- Update the relevant documentation when approved behavior or architecture changes.
- Do not create duplicate, conflicting definitions of task fields, routes, APIs, or status rules.
- Every planned implementation task must trace to a requirement or be identified as enabling work.
- Record deviations and known limitations.

## 10. Git and delivery

- No branch, commit-message, or pull-request convention has been specified. Do not invent one as an existing project rule.
- Preserve existing user work and inspect files before replacing them.
- Never claim a file, test, deployment, repository upload, or integration succeeded without evidence.
- Do not overwrite existing documentation without checking its contents and confirming replacement is appropriate.

## 11. Reporting format

At the end of a work session, report:
- What changed.
- Which requirement IDs were addressed.
- Tests run and actual results.
- Known limitations or failures.
- Assumptions made.
- Documentation that needs updating.
- Decisions that require the user's approval.
