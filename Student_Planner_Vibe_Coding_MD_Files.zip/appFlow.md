# Application Flow — Student Planner App

**Status:** Draft based on confirmed task-management features; optional flows are marked proposed  
**Related documents:** [PRD.md](PRD.md), [design.md](design.md), [database.md](database.md)

## 1. Screen inventory

| Screen/area | Status | Purpose |
|---|---|---|
| Planner home/dashboard | Inferred / proposed | Main place to view tasks and start actions |
| Add-task form or dialog | Required behavior; exact presentation unresolved | Enter task information and deadline |
| Task list | Required | Show tasks and their status |
| Task status filter | Proposed | Show all, pending, or completed tasks |
| Empty state | Required design consideration | Explain that there are no tasks yet |

No login or registration screen is specified because accounts are not a confirmed requirement.

## 2. Navigation overview

```mermaid
flowchart TD
    A[Open planner] --> B[View task list]
    B --> C[Add task]
    C --> D{Input valid?}
    D -- No --> E[Show validation feedback]
    E --> C
    D -- Yes --> F[Save task]
    F --> G[Show updated list]
    B --> H[Mark task complete]
    H --> I[Update task status]
    I --> G
    B --> J[Delete task]
    J --> K[Remove task from list]
    K --> G
```

## 3. Main task list

### Display
Each task should display enough information to identify the work and understand its state. The exact fields are still unresolved. At minimum, the title and completion status are implied; the deadline is required by the user's stated goal.

### Actions
- **Add task:** Opens or reveals the task form.
- **Mark completed:** Changes the task to completed and updates the visible status.
- **Delete:** Removes the task from the active list.
- **Filter:** Optional, pending approval.

### States
- **Normal:** Tasks are visible.
- **Empty:** No tasks exist; explain how to add the first task.
- **No filter results:** If filtering is implemented, explain that no tasks match the selected filter.
- **Storage failure:** Show an understandable message and do not claim an unsaved change succeeded.

## 4. Add-task flow

1. User chooses **Add task**.
2. App displays the task form.
3. User enters required information and selects a due date if supported.
4. User submits the form.
5. App validates required fields and date input.
6. If invalid, show a clear message and preserve entered values where practical.
7. If valid, create a task and persist it using the approved storage method.
8. If saving succeeds, update the list and provide feedback.
9. If saving fails, show an error and avoid falsely indicating success.

### Validation details
- A title is recommended as required, but the exact task-field specification needs approval.
- A date must be a valid calendar date if supplied.
- Whether a due date is required or optional is unresolved.
- Duplicate task titles are not prohibited by any confirmed rule.

## 5. Complete-task flow

1. User activates the completion control for a pending task.
2. App updates the task's completion state.
3. App persists the change.
4. The task visibly appears as completed; if a completed filter is used, it remains visible there.
5. If persistence fails, show an error and keep the displayed state consistent with saved data.

Whether users can reopen completed tasks is unresolved.

## 6. Delete-task flow

1. User chooses Delete for a task.
2. If a confirmation step is implemented, ask the user to confirm.
3. On confirmation, remove the task from storage and the list.
4. If deletion fails, show an error and keep the task visible.
5. On cancellation, do not change the task.

A confirmation dialog is recommended to prevent accidental deletion, but needs approval.

## 7. Deadline and overdue behavior

- The user explicitly wants assignment deadlines.
- The UI should display the saved due date.
- **Proposed rule:** A task is overdue when its due date is earlier than the user's current local date and it is not completed.
- The rule for tasks due today is not overdue under that proposal.
- Exact times, reminders, notifications, and timezone handling beyond date-only display are not confirmed.

## 8. Optional dashboard and filters

**Proposed, not confirmed:**
- Summary counts for total, pending, completed, and overdue tasks.
- Filters for All, Pending, and Completed.
- Sort tasks by due date.

Do not implement these optional features until their scope is accepted.

## 9. End-to-end acceptance scenarios

| Scenario | Action | Expected result |
|---|---|---|
| Create valid task | Enter valid required details and save | Task appears in the list and is pending |
| Missing title | Submit without a title, if title is required | Clear validation message; no task is created |
| Complete task | Mark pending task completed | Status changes to completed and is saved |
| Delete task | Delete an existing task | Task disappears after successful deletion |
| Reload app | Reload after saving, if persistence is selected | Previously saved tasks remain available within the chosen storage scope |
| Invalid saved data | Load malformed saved data | App handles it without crashing and communicates recovery/error appropriately |

## 10. Open questions

- Which fields appear in the task form?
- Is the due date required?
- Is delete confirmation required?
- Can a completed task be reopened?
- Are dashboard counts, filters, and sorting part of the MVP?
- Is browser-only persistence acceptable?
