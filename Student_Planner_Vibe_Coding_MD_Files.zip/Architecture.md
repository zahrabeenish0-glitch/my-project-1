# Architecture — Student Planner App

**Status:** Proposed architecture; pending platform and storage approval  
**Related documents:** [PRD.md](PRD.md), [TRD.md](TRD.md), [appFlow.md](appFlow.md), [database.md](database.md), [design.md](design.md)

## 1. Overview

The confirmed product is a student task planner with create, view, deadline, pending, completion, and delete capabilities. The system architecture cannot be finalized until the platform and storage approach are chosen.

## 2. Proposed architecture A: responsive website with browser storage

This is a recommendation for a small beginner MVP, not an approved decision.

```mermaid
flowchart TD
    U[Student] --> UI[Planner UI]
    UI --> V[Input validation]
    V --> S[Task state and task operations]
    S --> LS[(Browser localStorage)]
    LS --> S
    S --> UI
```

### Components

- **Planner UI:** Displays task form, task list, status, deadlines, and optional summary/filter controls.
- **Input validation:** Checks required values and date format before saving.
- **Task operations/state:** Creates tasks, changes completion status, deletes tasks, and calculates display status.
- **Browser storage adapter:** Reads and writes the task collection to local storage.
- **No backend/API:** This option does not need a server or API for the initial MVP.

## 3. Data flow: create task

```mermaid
sequenceDiagram
    actor Student
    participant UI as Planner UI
    participant Logic as Task logic
    participant Store as Browser storage
    Student->>UI: Enter task details and save
    UI->>Logic: Submit task data
    Logic->>Logic: Validate required fields
    alt Valid task
        Logic->>Store: Save updated task collection
        Store-->>Logic: Storage result
        Logic-->>UI: Updated tasks and success feedback
        UI-->>Student: Show new task
    else Invalid task
        Logic-->>UI: Validation message
        UI-->>Student: Show field-level feedback
    end
```

Storage errors must be handled; the UI should not report a successful save if persistence failed.

## 4. Task lifecycle

```mermaid
stateDiagram-v2
    [*] --> Pending: Task created
    Pending --> Completed: Mark complete
    Completed --> Pending: Reopen task, if supported
    Pending --> [*]: Delete task
    Completed --> [*]: Delete task
```

Reopening a completed task is **proposed but unresolved**. If not supported, remove that transition from the implementation.

## 5. Proposed module boundaries

If Option A is approved, keep modules simple:
- **UI/rendering:** Forms, task rows/cards, summary and filters if approved.
- **Task operations:** Validation, create/update/delete, status calculations.
- **Persistence:** Read/write task collection.
- **Tests:** Tests for validation, task operations, and storage behavior.

The actual folders and filenames depend on the selected stack and should be documented after approval. Do not create a backend layer unless a backend is selected.

## 6. Alternative architecture B: account-based cloud app

If cross-device access is required, a possible architecture is:

```mermaid
flowchart TD
    U[Student] --> UI[Web or mobile UI]
    UI --> AUTH[Authentication service]
    UI --> API[Backend or managed data service]
    API --> DB[(Cloud database)]
    API --> AUTH
```

This option requires a specific provider, authorization model, database schema, and deployment plan. None is currently approved.

## 7. Error handling and trust boundaries

For the browser-only option:
- Treat form input and stored data as potentially invalid.
- Validate before mutating task state.
- Handle unavailable or malformed storage gracefully.
- Do not store passwords, tokens, or sensitive information in task records.
- Show a clear message if a task change cannot be saved.

For a cloud option:
- Enforce task ownership at the backend/database boundary.
- Treat the browser as untrusted.
- Do not rely only on client-side checks for authorization.

## 8. Folder structure

**TODO:** Decide platform and stack first. A specific folder structure is intentionally not prescribed because it must match the chosen technology and the club's workflow.

## 9. Architecture decisions

| ID | Decision | Status | Reason / trade-off |
|---|---|---|---|
| ADR-001 | Start with a responsive website and local browser storage | Proposed | Simplest path for a demonstrable beginner MVP; no sync. |
| ADR-002 | Do not add authentication unless needed | Proposed | Avoids extra complexity while there is only one local user context. |
| ADR-003 | Keep task operations separate from UI rendering | Recommended | Makes behavior easier to test and maintain. |

## 10. Open questions

- Which platform and stack are required?
- Must users access tasks across devices?
- Is the user allowed to reopen completed tasks?
- Should the task list include filtering, priority, or course grouping?
